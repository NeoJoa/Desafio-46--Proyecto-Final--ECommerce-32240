const purchase = () => {
    fetch
}